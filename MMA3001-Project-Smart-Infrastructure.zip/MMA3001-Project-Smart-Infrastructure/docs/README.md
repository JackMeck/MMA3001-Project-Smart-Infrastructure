HTML API documentation is generated from the docstrings with
[pdoc](https://pdoc.dev). Regenerate it with `scripts/build_docs.sh`
(or `PYTHONPATH=src pdoc -o docs occupancy`) and commit the result. Open `docs/index.html`.
