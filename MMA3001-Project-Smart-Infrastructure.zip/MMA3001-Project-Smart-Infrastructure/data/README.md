# Data

The raw data (Monash Smart Infrastructure dataset, supplied for MMA3001, "Dataset 2")
is **not committed** because of licensing and privacy. Place the two CSV files here:

| File | Rows | Content |
| --- | --- | --- |
| `5EnvSensor_MayToDec2024_180kRows.csv` | ~180,000 | `sensorid`, `jsondata` (nested JSON of variable / (time, value) pairs) |
| `5occupancySensor_MayToDec2024_9MRows.csv` | ~9,000,000 | `floorspaceid`, `headcount`, `collecteddate` (ISO-8601 UTC) |

If you have the original zip files, point the pipeline at them instead and they are
unpacked here automatically:

```bash
python scripts/run_pipeline.py --zip-dir /path/to/zips --data-dir data
```
